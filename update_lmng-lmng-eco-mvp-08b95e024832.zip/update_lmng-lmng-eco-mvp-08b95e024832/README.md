![](/public/favicon.ico)

[![Styled With Prettier](https://img.shields.io/badge/code_style-prettier-ff69b4.svg)](https://prettier.io/)

### Install Dependencies

```bash
1. Front-end    `npm install --force`
2. Backe-end    `cd backend & npm install --force`
```

### Run

```bash
cd ..
npm start
```
