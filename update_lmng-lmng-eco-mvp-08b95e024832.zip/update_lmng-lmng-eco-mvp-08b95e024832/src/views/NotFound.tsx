import React from "react";

function NotFound() {
  return <div className="text-3xl text-center text-white">Page Not Found!</div>;
}

export default NotFound;
