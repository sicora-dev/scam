export const EAC_AGGREGATOR_PROXY_ADDRESS =
  "0x007A22900a3B98143368Bd5906f8E17e9867581b";
export const LUMANAGI_PREDICTION_V1_ADDRESS =
  "0x5e5fa41a6eA74bedA67E7644BC4B1e9eF3A7e793";
export const PREVIOUS_ROUNDS = 5;
export const NEXT_ROUNDS = 3;
export const SELECTED_NETWORK_LINK_HTTPS = "https://polygon-mumbai.infura.io/v3/9aa3d95b3bc440fa88ea12eaa4456161";
export const SELECTED_NETWORK_LINK_WSS = "wss://polygon-mumbai.infura.io/ws/v3/9aa3d95b3bc440fa88ea12eaa4456161";
